<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Student</title>
</head>
<body class="bg-dark">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <h1 class="text-white d-flex justify-content-center">Student List</h1>
    <a href="./studentRegistration.php" class="btn btn-outline-primary d-flex justify-content-center">Click Here For Add New</a>
    <br>
        <?php
            include_once "./classes/Student.php";
            $s= new Student();
            $stuArray=$s->getAllStudents();
            foreach ($stuArray as $key=>$value)
            {
        ?>
  <table class="table table-bordered table-dark border-primary  ">
    <tr>
        <th>Name:</th>
        <th>Enrollment:</th>
        <th>ℹ️</th>
        <th>⌫</th>
        <th>✎</th>
    </tr>
    <tr>
        <td><?php echo $value['enrollment'] ?></td>
        <td><?php echo $value['name'] ?></td>
        <td><a href="detailStudent.php?id=<?php echo $value['id']?>" class="btn btn-outline-primary">More Details</a></td>
        <td><a href="con_deleteStudent.php?id=<?php echo $value['id']?>" class="btn btn-outline-danger">Remove</a></td>
        <td><a href="editStudent.php?id=<?php echo $value['id']?>" class="btn btn-outline-warning">Edit</a></td>
    </tr>
    <tr>
        <td><a href="./index.php" class="btn btn-outline-primary">Back To Admin Panel</a></td>
    </tr>
</table>
</div>
        <?php
            }
        ?>
    </table>
</body>
</html>