<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quit Web Site</title>
    
    <link rel="icon" type="image/x-icon" href="logoo.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<?php
            include_once "./classes/Student.php";
            include_once "./listStudents.php";
            $id=$value['id'];
            $s= new Student();
            $stuArray=$s->getStudentById($id);
            foreach ($stuArray as $key=>$value)
            {
        ?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
        
                    <h2 class="mt-5 mb-3">Delete Records</h2>
                   
                        <div class="alert alert-danger">
                            <input type="hidden" name="hidden"/>
                            <p>Are you sure, you want to delete this record?</p>
                            
                               
                                <a href="con_deleteStudent.php?id=<?php echo $id?>" class="btn btn-secondary">Yes</a> 
                                <a href="./listStudents.php" class="btn btn-secondary">No</a>
                            
                        </div>
                    
                </div>
            </div>        
        </div>
    </div>
    <?php
            }
    ?>
</body>
</html>