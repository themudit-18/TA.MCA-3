INSERT INTO `students`(`id`, `name`, `enrollment`, `password`, `branch`, `sem`) VALUES (1,'mudit','607','mudit 5','computer','5')

INSERT INTO `students`(`id`, `name`, `enrollment`, `password`, `branch`, `sem`) VALUES (2,'meet','624','Meet 5','computer','4')

